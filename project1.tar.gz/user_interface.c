#include <stdio.h>
#include <stdlib.h>
#include "database.h"

void getAccountNum(int *account_num) {
     do {
          printf("Enter account number (positive integer): ");
          scanf("%d", account_num);
    } while (*account_num <= 0);
}

int main() {
     struct record *head = NULL;
     char filename[] = "database.txt";

     // Read from the file before user interaction
     readfile(&head, filename);

     int choice, account_num;
     char name[50], address[100];

     do {
          printf("\nMenu:\n");
          printf("1. Add Record\n");
          printf("2. Print All Records\n");
          printf("3. Find Record\n");
          printf("4. Delete Record\n");
          printf("5. Quit\n");
          printf("Choose an option: ");
          scanf("%d", &choice);

          switch (choice) {
               case 1:
                    getAccountNum(&account_num);
                    printf("Enter name: ");
                    scanf(" %[^\n]", name);
                    printf("Enter address: ");
                    scanf(" %[^\n]", address);
                    if (addRecord(&head, account_num, name, address) == -2) {
                         printf("Duplicate account number!\n");
                    }
                    break;
               case 2:
                    printAllRecords(head);
                    break;
               case 3:
                    getAccountNum(&account_num);
                    findRecord(head, account_num);
                    break;
               case 4:
                    getAccountNum(&account_num);
                    if (deleteRecord(&head, account_num) == -1) {
                         printf("Record not found for account number: %d\n", account_num);
                    } else {
                         printf("Record deleted.\n");
                    }
                    break;
               case 5:
                    writefile(head, filename);
                    cleanup(&head);
                    printf("Exiting program. Goodbye!\n");
                    break;
               default:
                    printf("Invalid option. Try again.\n");
                    break;
          }
     } while (choice != 5);

     return 0;
}

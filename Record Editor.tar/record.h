#ifndef RECORD_H
#define RECORD_H

struct record {
     int account_number;
     char name[50];
     char address[100];
     struct record *next;
};

#endif // RECORD_H

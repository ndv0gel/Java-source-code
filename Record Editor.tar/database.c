#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "database.h"

// Function to add a record
int addRecord(struct record **head, int account_number, char name[], char address[]) {
     struct record *new_record = malloc(sizeof(struct record));
     if (!new_record) return -1; // Memory allocation failure
     new_record->account_number = account_number;
     strcpy(new_record->name, name);
     strcpy(new_record->address, address);
     new_record->next = NULL;

     if (*head == NULL || (*head)->account_number > account_number) {
          new_record->next = *head;
          *head = new_record;
          return 0; // Record added
     }

     struct record *current = *head;
     while (current->next != NULL && current->next->account_number < account_number) {
          current = current->next;
     }

     if (current->account_number == account_number) {
          free(new_record);
          return -2; // Duplicate account number
     }

     new_record->next = current->next;
     current->next = new_record;
     return 0; // Record added
}

// Function to print all records
void printAllRecords(struct record *head) {
     while (head != NULL) {
          printf("Account Number: %d, Name: %s, Address: %s\n", head->account_number, head->name, head->address);
          head = head->next;
     }
}

// Function to find a record by account number
int findRecord(struct record *head, int account_number) {
     while (head != NULL) {
          if (head->account_number == account_number) {
               printf("Found: Account Number: %d, Name: %s, Address: %s\n", head->account_number, head->name, head->address);
               return 0; // Found
          }
          head = head->next;
     }
     printf("Record not found for account number: %d\n", account_number);
     return -1; // Not found
}

// Function to delete a record
int deleteRecord(struct record **head, int account_number) {
     struct record *current = *head;
     struct record *previous = NULL;

     while (current != NULL && current->account_number != account_number) {
          previous = current;
          current = current->next;
     }

     if (current == NULL) return -1; // Record not found

     if (previous == NULL) {
          *head = current->next; // Deleting the first record
     }
     else {
          previous->next = current->next; // Bypass the current record
     }
     free(current);
     return 0; // Record deleted
}

// Function to write records to a file
int writefile(struct record *head, char filename[]) {
     FILE *file = fopen(filename, "w");
     if (!file) return -1;

     struct record *current = head;
     while (current != NULL) {
          fprintf(file, "%d,%s,%s\n", current->account_number, current->name, current->address);
          current = current->next;
     }
     fclose(file);
     return 0;
}                                                                                                                                   

// Function to read records from a file
int readfile(struct record **head, char filename[]) {
     FILE *file = fopen(filename, "r");
     if (!file) return -1;

     int account_number;
     char name[50], address[100];
     while (fscanf(file, "%d,%49[^,],%99[^\n]\n", &account_number, name, address) == 3) {
          addRecord(head, account_number, name, address);
     }
     fclose(file);
     return 0;
}

// Function to cleanup records
void cleanup(struct record **head) {
     struct record *current = *head;
     while (current != NULL) {
          struct record *next = current->next;
          free(current);
          current = next;
     }
     *head = NULL; // Set head to NULL
}
